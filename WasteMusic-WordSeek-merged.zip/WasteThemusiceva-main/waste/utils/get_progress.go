/*
 * ● WasteMusic
 * ○ A high-performance engine for streaming music in Telegram voicechats.
 *
 * Copyright (C) 2026 Waste
 *
 * This program is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * Repository: https://github.com/Oyekanhaa/WasteMusic
 */

package utils

var progressBarCache = [9]string{
	"◉———————",
	"—◉——————",
	"——◉—————",
	"———◉————",
	"————◉———",
	"—————◉——",
	"——————◉—",
	"———————◉",
	"————————◉",
}

func GetProgressBar(playedSec, durationSec int) string {
	if durationSec <= 0 || playedSec <= 0 {
		return progressBarCache[0]
	}

	if playedSec >= durationSec {
		return progressBarCache[8]
	}

	index := min((playedSec*9)/durationSec, 8)

	return progressBarCache[index]
}
